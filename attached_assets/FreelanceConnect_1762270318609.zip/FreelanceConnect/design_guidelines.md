# Design Guidelines: Freelance Marketplace Platform

## Design Approach

**Selected Approach:** Design System with Modern Marketplace References

Drawing inspiration from **Linear's clean aesthetics** combined with **Upwork's information hierarchy**, this design prioritizes efficiency, scannability, and role-based clarity. The interface emphasizes data-dense displays while maintaining breathing room and visual hierarchy.

**Key Design Principles:**
- Clarity over decoration: Every element serves a functional purpose
- Role-based visual distinction: Subtle differences between freelancer and client interfaces
- Information density with breathing room: Compact layouts without feeling cramped
- Consistent patterns: Users learn once, apply everywhere

---

## Typography System

**Font Stack:** Inter (primary) via Google Fonts CDN, system fallback

**Hierarchy:**
- **Hero/Page Titles:** text-4xl (36px), font-bold, tracking-tight
- **Section Headers:** text-2xl (24px), font-semibold
- **Card Titles:** text-lg (18px), font-semibold
- **Body Text:** text-base (16px), font-normal, leading-relaxed
- **Secondary/Meta:** text-sm (14px), font-normal
- **Captions/Labels:** text-xs (12px), font-medium, uppercase tracking-wide

---

## Layout System

**Spacing Primitives:** Tailwind units of **2, 4, 6, 8, 12, 16**
- Micro spacing (between related elements): p-2, gap-2
- Standard spacing (cards, forms): p-4, p-6, gap-4
- Section spacing: p-8, py-12, py-16
- Page margins: px-4 (mobile), px-6 (tablet), px-8 (desktop)

**Grid System:**
- Container: max-w-7xl mx-auto
- Dashboard layout: 2-column (sidebar + main content)
  - Sidebar: w-64, fixed height, sticky positioning
  - Main content: flex-1, min-w-0 (prevents overflow)
- Card grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Job listings: Single column stacked cards with hover states

---

## Component Library

### Navigation

**Main Sidebar (Freelancer/Client Dashboards):**
- Fixed left sidebar, w-64, min-h-screen
- Logo at top (h-16 container)
- Navigation links: py-3 px-4, rounded-lg, font-medium
- Active state: Different background treatment
- User profile section at bottom: p-4, border-top separator
- Icons: Heroicons outline (24px) alongside text labels

**Top Navigation Bar (Public/Auth Pages):**
- Sticky top-0, backdrop-blur, border-bottom
- Container: max-w-7xl, flex justify-between items-center
- Height: h-16
- Logo left, navigation center, auth buttons right

### Cards & Containers

**Job Card:**
- Border, rounded-xl, p-6
- Header: flex justify-between items-start
  - Title (text-lg font-semibold) + Budget (text-xl font-bold)
- Meta row: flex gap-4, text-sm (Posted date, proposals count, skills)
- Description: line-clamp-3, leading-relaxed
- Footer: flex justify-between items-center, pt-4, border-top
  - Client info left, action button right
- Hover: subtle elevation increase, border treatment change

**Dashboard Stats Card:**
- Grid layout for stats overview: grid-cols-1 md:grid-cols-4 gap-6
- Individual stat card: p-6, rounded-lg, border
- Icon top (h-12 w-12, rounded-full background)
- Label: text-sm, font-medium
- Value: text-3xl, font-bold, mt-2
- Change indicator: text-sm with trend arrow

**Proposal Card:**
- Compact design: p-4, border-bottom (last:border-0)
- Freelancer avatar + name + rating (flex items-center gap-3)
- Proposal excerpt: line-clamp-2, mt-2
- Meta footer: flex justify-between, text-sm, mt-3
  - Bid amount left, time submitted right
- Action buttons: "View Details" + "Accept/Decline"

### Forms

**Input Fields:**
- Label: text-sm font-medium, mb-2
- Input: px-4 py-3, rounded-lg, border, text-base
- Focus state: ring treatment, border change
- Error state: red border + text-sm error message below
- Textarea: min-h-32, resize-vertical

**Job Posting Form:**
- Multi-step or single scrolling form
- Section groups with clear headers (text-xl font-semibold, mb-6)
- Field spacing: space-y-6
- Skills selector: Multi-select with tag display
- Budget input: Prefix ($) with number input
- Rich text editor for description (Quill or similar library)

**Search & Filters:**
- Sticky filter sidebar (on Browse Jobs page)
- Search bar: h-12, rounded-full, with search icon
- Filter groups: Collapsible accordions
- Checkbox lists for categories/skills
- Range slider for budget
- "Apply Filters" sticky button at bottom

### Data Displays

**Proposals Table (Client View):**
- Full-width table with responsive scroll
- Header: sticky top, background, border-bottom
- Columns: Freelancer | Proposal | Bid | Delivered | Status | Actions
- Row height: py-4
- Alternating row backgrounds for scannability
- Action dropdowns in last column

**Earnings Timeline (Freelancer):**
- Vertical timeline layout
- Each entry: flex layout with date marker left, details right
- Date marker: Circular node with connecting line
- Entry card: p-4, border-left accent, rounded-r
- Project name, client, amount, payment date

**Messages/Chat Interface:**
- Split view: Conversations list (w-80) + Chat window (flex-1)
- Conversation item: p-4, border-bottom, hover state
  - Avatar + name + last message preview (line-clamp-1)
  - Timestamp top-right
  - Unread indicator (dot or badge)
- Chat window: 
  - Header: sticky, p-4, border-bottom (user info)
  - Messages container: flex-1, overflow-y-auto, p-4
  - Message bubbles: max-w-md, p-3, rounded-2xl, mb-2
  - Input area: sticky bottom, p-4, border-top

### Buttons & Actions

**Primary Action:** px-6 py-3, rounded-lg, font-semibold, text-base
**Secondary Action:** px-6 py-3, rounded-lg, border-2, font-semibold
**Text Button:** px-4 py-2, font-medium, no background
**Icon Button:** p-2, rounded-lg, icon 20px

**Button Sizing:**
- Small: px-4 py-2, text-sm
- Medium: px-6 py-3, text-base (default)
- Large: px-8 py-4, text-lg

### Status Indicators

**Badges:**
- Inline: px-3 py-1, rounded-full, text-xs, font-medium
- Status types: Active, Pending, Completed, Rejected
- Each with distinct background + text treatment

**Progress Indicators:**
- Linear progress bar: h-2, rounded-full, overflow-hidden
- Circular progress (for profile completion): size-16 to size-24

---

## Page-Specific Layouts

### Login/Register Pages
- Centered card layout: max-w-md mx-auto, mt-20
- Card: p-8, rounded-2xl, border, shadow-sm
- Logo centered above, mb-8
- Form fields: space-y-4
- Role selector (radio buttons): Grid of two large cards, selectable
- Submit button: w-full, h-12
- Footer links: text-center, text-sm, mt-6

### Dashboard (Both Roles)
- 2-column: Sidebar (w-64) + Main (flex-1)
- Main header: p-8, border-bottom
  - Page title + action button (e.g., "Post New Job")
- Stats grid below header
- Main content section: p-8, space-y-8

### Browse Jobs (Freelancer)
- 2-column: Filters sidebar (w-72, sticky) + Job listings (flex-1)
- Job cards: space-y-4
- Pagination: Centered, py-8

### Job Details Modal/Page
- Modal: max-w-3xl, max-h-screen overflow-y-auto
- Header: p-8, border-bottom (Title + budget + meta)
- Content: p-8, prose max-w-none
- Sidebar: Client info card, sticky
- Footer: p-8, border-top, flex justify-end gap-4

### Profile Settings
- Single column form: max-w-3xl mx-auto
- Sections with clear separation: space-y-12
- Avatar upload: Large circular preview (size-32) with edit button
- Save button: sticky bottom-right corner

---

## Icons & Assets

**Icon Library:** Heroicons (outline variant) via CDN
- Navigation icons: 24px
- Card/inline icons: 20px
- Button icons: 16-20px

**Images:**
- User avatars: Circular, sizes: size-8 (small), size-12 (medium), size-16 (large)
- Default avatar: Initials on gradient background
- Empty states: Illustration placeholders (undraw.co or similar)

---

## Responsive Behavior

**Breakpoints:**
- Mobile: < 768px - Stack everything, hide sidebar (drawer menu)
- Tablet: 768px - 1024px - Some side-by-side, compressed layouts
- Desktop: > 1024px - Full layouts as specified

**Mobile Adaptations:**
- Sidebar becomes bottom nav or hamburger menu
- Tables become stacked cards
- Multi-column grids become single column
- Reduce padding (p-4 instead of p-8)

---

## Animation Guidelines

**Use Sparingly:**
- Page transitions: None (instant load)
- Modal open/close: Fade + scale (duration-200)
- Dropdown menus: Slide down (duration-150)
- Hover states: Background/border changes only (no transform)
- Loading states: Subtle spinner or skeleton screens