import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Briefcase, Users, DollarSign, MessageCircle, CheckCircle } from 'lucide-react';
import heroImage from '@assets/generated_images/Freelance_marketplace_hero_image_ad4d6d88.png';

export default function Home() {
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: Briefcase,
      title: 'Find Quality Projects',
      description: 'Browse hundreds of projects from clients worldwide and choose the ones that match your skills.'
    },
    {
      icon: Users,
      title: 'Hire Top Talent',
      description: 'Connect with skilled freelancers who can bring your projects to life with expertise and professionalism.'
    },
    {
      icon: DollarSign,
      title: 'Secure Payments',
      description: 'Safe and reliable payment system that protects both freelancers and clients throughout the project.'
    },
    {
      icon: MessageCircle,
      title: 'Direct Communication',
      description: 'Built-in messaging system to collaborate seamlessly with your team members in real-time.'
    }
  ];

  const benefits = [
    'Create professional profile and showcase your work',
    'Access to thousands of projects across various industries',
    'Transparent pricing and secure milestone-based payments',
    'Build long-term relationships with clients and freelancers',
    'Track earnings and manage projects from one dashboard',
    '24/7 support to help you succeed'
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-primary">FreelanceHub</h1>
            <p className="text-xs text-muted-foreground">Connect. Collaborate. Create.</p>
          </div>
          <div className="flex gap-3">
            <Button
              data-testid="button-nav-login"
              variant="outline"
              onClick={() => setLocation('/login')}
            >
              Log In
            </Button>
            <Button
              data-testid="button-nav-signup"
              onClick={() => setLocation('/register')}
            >
              Sign Up
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black/70 to-black/50 z-10" />
        <img 
          src={heroImage} 
          alt="Freelance marketplace" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 container mx-auto px-6 py-24 md:py-32 text-white">
          <div className="max-w-3xl">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Your Gateway to Freelance Success
            </h2>
            <p className="text-xl md:text-2xl mb-8 text-white/90 leading-relaxed">
              Connect talented freelancers with clients worldwide. Build your career or find the perfect expert for your next project.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button
                data-testid="button-hero-get-started"
                size="lg"
                variant="default"
                className="bg-primary text-primary-foreground border border-primary hover:bg-primary/90"
                onClick={() => setLocation('/register')}
              >
                Get Started Free
              </Button>
              <Button
                data-testid="button-hero-learn-more"
                size="lg"
                variant="outline"
                className="bg-background/20 backdrop-blur-sm border-white/30 text-white hover:bg-background/30"
                onClick={() => {
                  document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold mb-4">Why Choose FreelanceHub?</h3>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to succeed in the freelance economy, all in one platform
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Card key={feature.title} className="p-6 hover-elevate">
                <div className="p-4 bg-primary/10 rounded-lg w-fit mb-4">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h4 className="text-xl font-semibold mb-3">{feature.title}</h4>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-4xl font-bold mb-6">Built for Success</h3>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Whether you're a freelancer looking to grow your business or a client seeking top talent, 
                FreelanceHub provides all the tools you need to succeed.
              </p>
              <div className="space-y-4">
                {benefits.map((benefit) => (
                  <div key={benefit} className="flex items-start gap-3">
                    <div className="p-1 bg-primary/10 rounded-full mt-1">
                      <CheckCircle className="w-5 h-5 text-primary" />
                    </div>
                    <p className="text-muted-foreground">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <Card className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">10K+</div>
                <p className="text-muted-foreground">Active Freelancers</p>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">5K+</div>
                <p className="text-muted-foreground">Projects Posted</p>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">$2M+</div>
                <p className="text-muted-foreground">Earned by Freelancers</p>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">98%</div>
                <p className="text-muted-foreground">Satisfaction Rate</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-4xl font-bold mb-6">Ready to Get Started?</h3>
          <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
            Join thousands of freelancers and clients who are already building their success on FreelanceHub
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              data-testid="button-cta-signup"
              size="lg"
              variant="outline"
              className="bg-background text-foreground border-background hover:bg-background/90"
              onClick={() => setLocation('/register')}
            >
              Create Free Account
            </Button>
            <Button
              data-testid="button-cta-login"
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
              onClick={() => setLocation('/login')}
            >
              Sign In
            </Button>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">FreelanceHub</h4>
              <p className="text-sm text-muted-foreground">
                The modern platform connecting freelancers and clients worldwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Freelancers</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Find Work</li>
                <li>How It Works</li>
                <li>Success Stories</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Clients</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Post a Job</li>
                <li>Find Talent</li>
                <li>Enterprise Solutions</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Terms of Service</li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2024 FreelanceHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
