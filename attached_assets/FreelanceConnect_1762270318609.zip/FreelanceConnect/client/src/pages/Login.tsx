import { useState } from 'react';
import { useLocation } from 'wouter';
import AuthLayout from '@/components/AuthLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Login:', { email, password });
    
    // todo: remove mock functionality - simulate login redirect to profile
    const mockRole = email.includes('client') ? 'client' : 'freelancer';
    localStorage.setItem('userRole', mockRole);
    localStorage.setItem('userEmail', email);
    
    if (mockRole === 'freelancer') {
      setLocation('/freelancer/profile');
    } else {
      setLocation('/client/profile');
    }
  };

  return (
    <AuthLayout>
      <Card className="p-8">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold mb-2">Welcome Back</h2>
          <p className="text-muted-foreground">Sign in to your account</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              data-testid="input-email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              data-testid="input-password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <Button
            data-testid="button-login"
            type="submit"
            className="w-full"
          >
            Sign In
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{' '}
            <button
              data-testid="link-register"
              onClick={() => setLocation('/register')}
              className="text-primary hover:underline"
            >
              Sign up
            </button>
          </p>
        </div>
        
        <div className="mt-4 p-3 bg-muted rounded-md">
          <p className="text-xs text-muted-foreground text-center">
            Demo: Use "freelancer@demo.com" or "client@demo.com"
          </p>
        </div>
      </Card>
    </AuthLayout>
  );
}
