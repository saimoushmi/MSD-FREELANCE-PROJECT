import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export default function Profile() {
  const [name, setName] = useState('John Doe');
  const [email, setEmail] = useState('john@example.com');
  const [bio, setBio] = useState('Experienced developer with 5+ years in React and Node.js');
  const [skills, setSkills] = useState('React, TypeScript, Node.js');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Profile updated:', { name, email, bio, skills });
    alert('Profile updated successfully!');
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Profile Settings</h1>
        <p className="text-muted-foreground">Manage your account information</p>
      </div>

      <Card className="p-8 max-w-3xl">
        <div className="flex items-center gap-6 mb-8 pb-8 border-b">
          <Avatar className="w-24 h-24">
            <AvatarFallback className="text-2xl">JD</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-lg font-semibold mb-1">{name}</h3>
            <p className="text-sm text-muted-foreground mb-3">{email}</p>
            <Button data-testid="button-change-photo" variant="outline" size="sm">
              Change Photo
            </Button>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              data-testid="input-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              data-testid="input-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              data-testid="textarea-bio"
              rows={4}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="skills">Skills (comma-separated)</Label>
            <Input
              id="skills"
              data-testid="input-skills"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              placeholder="React, TypeScript, Node.js"
            />
          </div>

          <Button
            data-testid="button-save-profile"
            type="submit"
            className="w-full"
          >
            Save Changes
          </Button>
        </form>
      </Card>
    </div>
  );
}
