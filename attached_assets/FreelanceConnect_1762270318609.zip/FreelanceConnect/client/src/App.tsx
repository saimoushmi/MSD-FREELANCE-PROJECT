import { Switch, Route, Redirect } from 'wouter';
import { queryClient } from './lib/queryClient';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Home from '@/pages/Home';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import DashboardLayout from '@/components/DashboardLayout';
import FreelancerDashboard from '@/pages/FreelancerDashboard';
import BrowseJobs from '@/pages/BrowseJobs';
import MyProposals from '@/pages/MyProposals';
import Earnings from '@/pages/Earnings';
import Messages from '@/pages/Messages';
import Profile from '@/pages/Profile';
import ClientDashboard from '@/pages/ClientDashboard';
import PostJob from '@/pages/PostJob';
import ViewProposals from '@/pages/ViewProposals';
import ManageFreelancers from '@/pages/ManageFreelancers';
import Payment from '@/pages/Payment';

function ProtectedRoute({ role, component: Component }: { role: 'freelancer' | 'client', component: React.ComponentType }) {
  const userRole = localStorage.getItem('userRole');
  
  if (!userRole) {
    return <Redirect to="/login" />;
  }
  
  if (userRole !== role) {
    return <Redirect to={`/${userRole}/dashboard`} />;
  }
  
  return (
    <DashboardLayout role={role}>
      <Component />
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      <Route path="/freelancer/dashboard">
        {() => <ProtectedRoute role="freelancer" component={FreelancerDashboard} />}
      </Route>
      <Route path="/freelancer/browse-jobs">
        {() => <ProtectedRoute role="freelancer" component={BrowseJobs} />}
      </Route>
      <Route path="/freelancer/proposals">
        {() => <ProtectedRoute role="freelancer" component={MyProposals} />}
      </Route>
      <Route path="/freelancer/earnings">
        {() => <ProtectedRoute role="freelancer" component={Earnings} />}
      </Route>
      <Route path="/freelancer/messages">
        {() => <ProtectedRoute role="freelancer" component={Messages} />}
      </Route>
      <Route path="/freelancer/profile">
        {() => <ProtectedRoute role="freelancer" component={Profile} />}
      </Route>
      
      <Route path="/client/dashboard">
        {() => <ProtectedRoute role="client" component={ClientDashboard} />}
      </Route>
      <Route path="/client/post-job">
        {() => <ProtectedRoute role="client" component={PostJob} />}
      </Route>
      <Route path="/client/proposals">
        {() => <ProtectedRoute role="client" component={ViewProposals} />}
      </Route>
      <Route path="/client/freelancers">
        {() => <ProtectedRoute role="client" component={ManageFreelancers} />}
      </Route>
      <Route path="/client/messages">
        {() => <ProtectedRoute role="client" component={Messages} />}
      </Route>
      <Route path="/client/payment">
        {() => <ProtectedRoute role="client" component={Payment} />}
      </Route>
      <Route path="/client/profile">
        {() => <ProtectedRoute role="client" component={Profile} />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
